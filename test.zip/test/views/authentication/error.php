<?php
echo "fail";