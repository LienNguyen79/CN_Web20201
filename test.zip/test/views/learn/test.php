<!DOCTYPE html>
<html>
  <head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang chủ</title>
    
  <link rel="stylesheet" href="assets/css/home_style.css" type="text/css">
  </head>
<body>

<?php include_once ('views/homepage/header.php'); ?>
  <section style="height:80%">
  <h1 style="text-align:center; text-size:20px; font-weigh:bold; margin-top:25%;"> Đây là chế độ Kiểm tra</h1>
</section>
<?php include_once ('views/homepage/footer.php'); ?>
  
</body>
</html>