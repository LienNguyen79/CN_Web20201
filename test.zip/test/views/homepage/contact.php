
<!DOCTYPE html>
<html>
  <head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liên hệ</title>
    
  <link rel="stylesheet" href="assets/css/home_style.css" type="text/css">
  </head>
<body>

<?php include_once ('views/homepage/header.php'); ?>
    <section class="contact_us">
        <div>
            <h4>Trang chủ / Kết nối với chúng tôi</h4>
                <div class ="contact_info">
                    <p><span> Địa chỉ :</span> Số 1 Đại Cồ Việt, Phường Bách Khoa, Quận Hai Bà Trưng, Hà Nội </p>
                    <p><span> Điện thoại :</span> +84 964530128</p>
                    <p><span> Email : </span>huynguyenquang344@gmail.com </p>
                </div>
        </div>
    </section>
  <?php include_once ('views/homepage/footer.php'); ?>
</body>
</html>