
<!DOCTYPE html>
<html>
  <head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Về chúng tôi</title>
    
  <link rel="stylesheet" href="assets/css/home_style.css" type="text/css">
  </head>
<body>

<?php include_once ('views/homepage/header.php'); ?>
    <section class="contact_us">
        <div>
            <h4>Trang chủ / Sứ mệnh của Etrain</h4>
            <h2>Nhu cầu học tiếng Anh ở Việt Nam cũng như tại nhiều quốc gia khác không chỉ đến từ đòi hỏi của quá trình toàn cầu hóa mà còn đến từ đòi hỏi của các bậc phụ huynh. Cả xã hội từ thành thị đến nông thôn sẵn sàng đầu tư cho con em học ngoại ngữ nhưng kết quả lại không như mong đợi” - PGS.TS Lê Văn Canh phân tích.</h2>
            <h2> Etrain ra đời nhằm mục đích để học sinh /sinh viên tự nâng cao từ vựng tiếng anh mỗi ngày cho bản thân </h2>
        </div>
    </section>
<?php include_once ('views/homepage/footer.php'); ?>

</body>
</html>