<?php
require_once('controllers' . DS .'base_controller.php');
require_once('models'. DS .'word.php');
class HomepageController extends BaseController{
    function __construct()
    {
        $this->folder = 'homepage';
        
    }
    function home(){
        $this->render('home'); 
        if (isset($_POST['searchSubmit'])){
            $searchWord = $_POST['searchWord']; 
            //echo $searchWord;
            if (strlen(trim($searchWord)) > 1){
               $words = new Word; 
               $data = $words->find($searchWord);
               $data = array('words' => $data);
               $this->render('home', $data);
               //header("Refresh: 10; url=../test/index.php?controller=homepage&action=home");
               echo '<dialog open style="color: green; text-align: center; display: middle">
               <p>Thêm từ thành công</p>
               <p> Hãy xem trong: Kho từ của bạn </p>
               <a href="../test/index.php?controller=homepage&action=home"><button>OK</button></a>
             </dialog>';
              //  $data = array('words' => $data);
                //var_dump($data);
              //  $this->folder = 'learn';
              //  $this->render('gender_search',$data);
           
        }
      } 
    }
    
    public function upload(){

        $this->render('word_form');
      }
    

    public function about(){
      $this->folder = 'homepage';
        $this -> render('about');
      }

      public function contact(){
        $this->folder = 'homepage';
        $this -> render('contact');
      }
}